import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'vsf-checkout-sign-in',
  templateUrl: './checkout-sign-in.component.html',
  styleUrls: ['./checkout-sign-in.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CheckoutSignInComponent {
}
