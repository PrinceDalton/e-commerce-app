import { Directive } from '@angular/core';

@Directive({
    selector: '[vsfDropdownContent]',
})
export class DropdownContentDirective {
}
