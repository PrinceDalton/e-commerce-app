import { Directive } from '@angular/core';

@Directive({
    selector: '[vsfDropdownTrigger]',
})
export class DropdownTriggerDirective {
}
