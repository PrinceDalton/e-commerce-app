export const environment = {
    production: true,
    apiHost: 'http://localhost',
    apiPort: 3000,
    shopApiPath: 'shop-api',
    baseHref: '/',
    tokenMethod: 'bearer',
};
