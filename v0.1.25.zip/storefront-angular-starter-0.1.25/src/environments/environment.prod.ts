export const environment = {
    production: true,
    apiHost: 'https://demo.vendure.io',
    apiPort: 443,
    shopApiPath: 'shop-api',
    baseHref: '/storefront/',
    tokenMethod: 'cookie',
};
